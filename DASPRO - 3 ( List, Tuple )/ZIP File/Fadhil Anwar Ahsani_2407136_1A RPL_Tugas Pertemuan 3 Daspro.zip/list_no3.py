############################
# Nim   : 2407136
# Nama  : Fadhil Anwar Ahsani
# Kelas : 1A
############################

## Latihan Studi Kasus pada Tipe Data List ##

# 3. Ganti item dengan nama “ceri” menjadi “cherry”

buah = ["apel", "jeruk", "ceri", "durian", "apel", "mangga"]

buah[2] = "cherry"

print(buah)

