############################
# Nim   : 2407136
# Nama  : Fadhil Anwar Ahsani
# Kelas : 1A
############################

## Latihan Studi Kasus pada Tipe Data List ##

# 5. Urutkan item pada list sesuai dengan abjadnya

buah = ["apel", "jeruk", "ceri", "durian", "apel", "mangga"]

buah.sort()

print(buah)

