############################
# Nim   : 2407136
# Nama  : Fadhil Anwar Ahsani
# Kelas : 1A
############################

## Latihan Studi Kasus pada Tipe Data List ##

# 4. Tambahkan item dengan nama “strawberry” ke dalam index ke-3

buah = ["apel", "jeruk", "ceri", "durian", "apel", "mangga"]

buah.insert(3, "strawberry")

print(buah)
