############################
# Nim   : 2407136
# Nama  : Fadhil Anwar Ahsani
# Kelas : 1A
############################

## Latihan Studi Kasus pada Tipe Data Tuple ##

# 1. Buatlah program untuk mengambil tuple ke 2-5

buah = ("apel", "jeruk", "ceri", "durian", "apel", "mangga")

print(buah[1:5])


        