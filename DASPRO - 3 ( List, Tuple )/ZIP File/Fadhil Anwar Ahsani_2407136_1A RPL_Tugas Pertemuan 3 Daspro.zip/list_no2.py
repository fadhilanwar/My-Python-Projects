############################
# Nim   : 2407136
# Nama  : Fadhil Anwar Ahsani
# Kelas : 1A
############################

## Latihan Studi Kasus pada Tipe Data List ##

# 1. Hapus item “apel“ yang kedua

buah = ["apel", "jeruk", "ceri", "durian", "apel", "mangga"]

buah.pop(4)

print(buah)
