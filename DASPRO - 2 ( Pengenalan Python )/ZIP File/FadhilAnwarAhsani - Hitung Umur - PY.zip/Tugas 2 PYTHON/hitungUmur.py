############################
# Nim   : 2407136
# Nama  : Fadhil Anwar Ahsani
# Kelas : 1A
############################
print("Welcome, Ini adalah Program untuk menghitung Umur Anda!")
who_are_you = input("Masukkan Nama anda: ")
umur = int(input("Tahun lahir: "))
tahun_ini = 2024
hitung_umur =  tahun_ini - umur

print(f"Jadi, {who_are_you} terhitung pada Tahun {tahun_ini} Umur kamu adalah {hitung_umur}thn")
print("Terimakasih sudah Menggunakan :)")