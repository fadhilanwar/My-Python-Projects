############################
# Nim   : 2407136
# Nama  : Fadhil Anwar Ahsani
# Kelas : 1A
############################

## Latihan untuk Menghitung Luas Segitiga ##

print("Ini adalah program untuk menghitung Luas Segitiga")
alas = int(input("Masukkan Nilai Alas: "))
tinggi = int(input("Masukkan Nilai Tinggi: "))
hitungLuas = (alas*tinggi) / 2

print(f"Segitiga tersebut memiliki Luas {hitungLuas}")

