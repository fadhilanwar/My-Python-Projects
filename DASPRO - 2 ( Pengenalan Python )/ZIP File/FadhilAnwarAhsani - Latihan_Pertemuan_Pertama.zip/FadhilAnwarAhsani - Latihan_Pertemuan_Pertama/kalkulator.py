############################
# Nim   : 2407136
# Nama  : Fadhil Anwar Ahsani
# Kelas : 1A
############################

## Latihan untuk membuat program Kalkulator ##

input_1 = int(input("Masukkan Angka Pertama: "))
input_2 = int(input("Masukkan Angka Kedua: "))
input_3 = int(input("Masukkan Angka Ketiga: "))

hasil = input_1 + input_2 + input_3

print(f"Hasil Perhitungan: {hasil}")