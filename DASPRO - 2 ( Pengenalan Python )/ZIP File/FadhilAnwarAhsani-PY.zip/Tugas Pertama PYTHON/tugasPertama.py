############################
# Nim   : 2407136
# Nama  : Fadhil Anwar Ahsani
# Kelas : 1A
############################
who_are_you = input("Masukkan Nama anda: ")
umur = input("Berapa Umur kamu: ")
print(f"Got It!, Jadi namamu adalah {who_are_you} dan Umur kamu adalah {umur}thn")
print("Terimakasih sudah Menggunakan :)")