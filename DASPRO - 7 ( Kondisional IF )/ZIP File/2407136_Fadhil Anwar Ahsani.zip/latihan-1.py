'''
Nama : Fadhil Anwar Ahsani
Kelas : 1A - RPL
NIM : 2407136
'''

nilai = float(input("Masukkan nilai akhir mahasiswa: "))

if nilai >= 60:
    predikat = "Selamat, Lulus"
    print(predikat)
elif nilai < 60:
    predikat = "MAAF, Tidak Lulus"
    print(predikat)
